"""
server.py — Hydroponics Plant Growth Monitor Server
=====================================================
TAILORED FOR:  Lettuce, Kangkong, Mustasa (hydroponics)
AI BACKEND:    Roboflow (custom trained model)

WHAT THIS DOES:
  1. Waits for the ESP32-CAM to POST a photo every morning at 8:00 AM
  2. Sends the photo to your Roboflow model for growth stage detection
  3. Saves the photo and appends one row to plant_growth_log.csv
  4. Serves a local web dashboard at http://localhost:5000

HOW TO RUN:
  pip install flask requests Pillow
  python server.py

OPEN DASHBOARD IN BROWSER:
  http://localhost:5000

⚠️  PLUG IN YOUR VALUES below — find every line marked # <-- CHANGE THIS
"""

import os
import csv
import json
import base64
import requests
from datetime import datetime
from flask import (Flask, request, jsonify, render_template_string,
                   send_from_directory, send_file)
from PIL import Image
import io

# ============================================================
# ⚠️  ROBOFLOW CONFIGURATION
# ============================================================
# How to get these values:
#   1. Go to roboflow.com and open your project
#   2. Click Versions → select your trained version → Deploy tab
#   3. The API key, model ID, and version are all shown there

ROBOFLOW_API_KEY    = "YOUR_ROBOFLOW_API_KEY"    # <-- CHANGE THIS
ROBOFLOW_MODEL_ID   = "your-hydro-model-name"    # <-- CHANGE THIS  e.g. "kangkong-growth-stages"
ROBOFLOW_VERSION    = "1"                         # <-- CHANGE THIS  e.g. "1" or "2"
ROBOFLOW_CONFIDENCE = 30                          # Accept predictions >= 30% confidence (lower = more detections)

# ============================================================
# ⚠️  PLANT CONFIGURATION
# ============================================================
PLANT_SPECIES = "Kangkong"   # <-- CHANGE THIS  e.g. "Lettuce", "Kangkong", "Mustasa"

# ============================================================
# Roboflow Class → Growth Stage Mapping
# ============================================================
# ⚠️  The KEYS here must exactly match the class names you used
#    when labeling your images in Roboflow (lowercase, no spaces).
#
# RECOMMENDED class names to use when labeling in Roboflow:
#   "germination"  — Seed sprouted, cotyledon emerging       (Day 1–3)
#   "seedling"     — First true leaves visible               (Day 4–10)
#   "vegetative"   — Rapid leaf expansion, bushy growth      (Day 11–25)
#   "mature"       — Full leaves, harvest-ready              (Day 26+)
#   "overgrown"    — Past harvest, bolting / flowering
#   "stressed"     — Yellowing, wilting, or abnormal growth
#
GROWTH_STAGE_MAP = {
    "germination": "Germination",
    "seedling":    "Seedling",
    "vegetative":  "Vegetative",
    "mature":      "Mature",
    "harvest":     "Mature",       # treat "harvest" as Mature
    "overgrown":   "Overgrown",
    "bolting":     "Overgrown",
    "stressed":    "Stressed",
    "yellowing":   "Stressed",
    "wilted":      "Stressed",
    "healthy":     "Vegetative",   # if your model uses "healthy" as a general class
}

# Growth stage → health label
HEALTH_MAP = {
    "Germination": "Healthy",
    "Seedling":    "Healthy",
    "Vegetative":  "Healthy",
    "Mature":      "Healthy",
    "Overgrown":   "Attention Needed",
    "Stressed":    "Stressed",
}

# Growth stage → estimated growing day range (display only)
DAYS_RANGE_MAP = {
    "Germination": "Day 1–3",
    "Seedling":    "Day 4–10",
    "Vegetative":  "Day 11–25",
    "Mature":      "Day 26+",
    "Overgrown":   "Day 30+",
    "Stressed":    "—",
}

# ============================================================
# File Paths & Server Settings
# ============================================================
CSV_FILE      = "plant_growth_log.csv"
IMAGES_FOLDER = "images"
SERVER_PORT   = 5000
DEBUG_MODE    = True

# ============================================================
# CSV Column Headers
# ============================================================
CSV_HEADERS = [
    "date",                # 2025-02-19
    "time",                # 08:00:41
    "timestamp",           # 2025-02-19T08:00:41
    "plant_species",       # Kangkong
    "device_id",           # cam_01
    "filename",            # plant_2025-02-19_08-00-41_cam_01.jpg
    "growth_stage",        # Vegetative
    "estimated_day_range", # Day 11–25
    "health_status",       # Healthy
    "confidence",          # 0.91
    "detected_class",      # vegetative  (raw Roboflow label)
    "all_detections",      # JSON list of all predictions
    "image_width",         # 800
    "image_height",        # 600
    "roboflow_model",      # kangkong-growth-stages/v1
    "notes",               # "3 prediction(s) returned"
]

# ============================================================
# App Setup
# ============================================================
app = Flask(__name__)
os.makedirs(IMAGES_FOLDER, exist_ok=True)

if not os.path.exists(CSV_FILE):
    with open(CSV_FILE, "w", newline="", encoding="utf-8") as f:
        csv.DictWriter(f, fieldnames=CSV_HEADERS).writeheader()
    print(f"Created {CSV_FILE}")

print("=" * 55)
print(f"  Hydroponics Monitor — {PLANT_SPECIES}")
print(f"  Dashboard : http://localhost:{SERVER_PORT}")
print(f"  Upload    : http://localhost:{SERVER_PORT}/upload")
print(f"  CSV log   : {CSV_FILE}")
print(f"  Model     : {ROBOFLOW_MODEL_ID} v{ROBOFLOW_VERSION}")
print("=" * 55)


# ============================================================
# Route: /upload  — ESP32-CAM posts photos here at 8:00 AM
# ============================================================
@app.route("/upload", methods=["POST"])
def upload():
    # 1. Validate incoming file
    if "file" not in request.files:
        return jsonify({"error": "No file in request"}), 400
    file = request.files["file"]
    if file.filename == "":
        return jsonify({"error": "Empty filename"}), 400

    # 2. Read form metadata sent by ESP32
    device_id = request.form.get("device_id", "cam_01")

    now      = datetime.now()
    date_str = now.strftime("%Y-%m-%d")
    time_str = now.strftime("%H:%M:%S")
    iso_ts   = now.isoformat(timespec="seconds")
    safe_ts  = now.strftime("%Y-%m-%d_%H-%M-%S")

    # 3. Save image to disk with timestamped filename
    filename = f"plant_{safe_ts}_{device_id}.jpg"
    filepath = os.path.join(IMAGES_FOLDER, filename)
    image_bytes = file.read()

    with open(filepath, "wb") as f:
        f.write(image_bytes)

    print(f"\n  Received: {filename}  ({len(image_bytes)/1024:.1f} KB)")

    # 4. Get image dimensions using Pillow
    try:
        img = Image.open(io.BytesIO(image_bytes))
        img_w, img_h = img.size
    except Exception:
        img_w, img_h = 0, 0

    # 5. Send to Roboflow for analysis
    result = analyze_with_roboflow(image_bytes)
    print(f"  Stage: {result['growth_stage']}  |  "
          f"Confidence: {result['confidence']*100:.1f}%  |  "
          f"Health: {result['health_status']}")

    # 6. Append one row to the CSV log
    row = {
        "date":               date_str,
        "time":               time_str,
        "timestamp":          iso_ts,
        "plant_species":      PLANT_SPECIES,
        "device_id":          device_id,
        "filename":           filename,
        "growth_stage":       result["growth_stage"],
        "estimated_day_range":result["estimated_day_range"],
        "health_status":      result["health_status"],
        "confidence":         result["confidence"],
        "detected_class":     result["detected_class"],
        "all_detections":     json.dumps(result["all_detections"]),
        "image_width":        img_w,
        "image_height":       img_h,
        "roboflow_model":     f"{ROBOFLOW_MODEL_ID}/v{ROBOFLOW_VERSION}",
        "notes":              result["notes"],
    }

    with open(CSV_FILE, "a", newline="", encoding="utf-8") as f:
        csv.DictWriter(f, fieldnames=CSV_HEADERS).writerow(row)

    print(f"  Logged to CSV\n")
    return jsonify({"status": "ok", "filename": filename, "analysis": result}), 200


# ============================================================
# Roboflow Analysis
# ============================================================
def analyze_with_roboflow(image_bytes: bytes) -> dict:
    """
    Encodes image as base64 and POSTs to Roboflow Inference API.
    Returns a structured dict with growth stage, confidence, health.

    Object Detection endpoint (use if you drew bounding boxes):
      https://detect.roboflow.com/<MODEL_ID>/<VERSION>

    Classification endpoint (use if you labeled whole images):
      https://classify.roboflow.com/<MODEL_ID>/<VERSION>

    Change 'detect' to 'classify' in the url below if needed.
    """
    url = (
        f"https://detect.roboflow.com"          # <-- change 'detect' to 'classify' if needed
        f"/{ROBOFLOW_MODEL_ID}/{ROBOFLOW_VERSION}"
        f"?api_key={ROBOFLOW_API_KEY}"
        f"&confidence={ROBOFLOW_CONFIDENCE}"
        f"&overlap=50"
        f"&format=json"
    )

    b64_image = base64.b64encode(image_bytes).decode("utf-8")

    try:
        resp = requests.post(
            url,
            data=b64_image,
            headers={"Content-Type": "application/x-www-form-urlencoded"},
            timeout=30,
        )
        resp.raise_for_status()
        data = resp.json()

    except requests.exceptions.Timeout:
        return _error_result("Roboflow API timed out after 30 seconds")
    except requests.exceptions.HTTPError as e:
        status_code = e.response.status_code if e.response else 0
        message = {
            401: "Invalid API key — re-check ROBOFLOW_API_KEY in server.py",
            404: "Model not found — check ROBOFLOW_MODEL_ID and ROBOFLOW_VERSION",
            429: "API rate limit exceeded — wait and try again",
        }.get(status_code, f"HTTP {status_code} error from Roboflow")
        return _error_result(message)
    except requests.exceptions.RequestException as e:
        return _error_result(f"Network error: {e}")

    predictions = data.get("predictions", [])

    if not predictions:
        return {
            "growth_stage":        "No Detection",
            "estimated_day_range": "—",
            "health_status":       "Unknown",
            "confidence":          0.0,
            "detected_class":      "",
            "all_detections":      [],
            "notes": (
                "No objects detected. Possible reasons: "
                "1) plant not visible in frame, "
                "2) class names in GROWTH_STAGE_MAP do not match your Roboflow model labels, "
                "3) try lowering ROBOFLOW_CONFIDENCE."
            ),
        }

    # Use the prediction with the highest confidence as the primary result
    best       = max(predictions, key=lambda p: p.get("confidence", 0))
    raw_class  = best.get("class", "unknown").lower().strip()
    confidence = round(best.get("confidence", 0.0), 4)

    # Map raw class → display labels using the maps defined at the top of the file
    growth_stage  = GROWTH_STAGE_MAP.get(raw_class, raw_class.title())
    health_status = HEALTH_MAP.get(growth_stage, "Unknown")
    day_range     = DAYS_RANGE_MAP.get(growth_stage, "—")

    return {
        "growth_stage":        growth_stage,
        "estimated_day_range": day_range,
        "health_status":       health_status,
        "confidence":          confidence,
        "detected_class":      raw_class,
        "all_detections": [
            {
                "class":      p.get("class"),
                "confidence": round(p.get("confidence", 0), 3),
                "x":          round(p.get("x", 0)),
                "y":          round(p.get("y", 0)),
                "width":      round(p.get("width", 0)),
                "height":     round(p.get("height", 0)),
            }
            for p in predictions
        ],
        "notes": f"{len(predictions)} prediction(s) returned by model",
    }


def _error_result(reason: str) -> dict:
    """Returns a safe empty result when something goes wrong."""
    return {
        "growth_stage":        "Error",
        "estimated_day_range": "—",
        "health_status":       "Unknown",
        "confidence":          0.0,
        "detected_class":      "",
        "all_detections":      [],
        "notes":               reason,
    }


# ============================================================
# Route: /  — Web Dashboard
# ============================================================
@app.route("/")
def dashboard():
    rows = []
    if os.path.exists(CSV_FILE):
        with open(CSV_FILE, "r", encoding="utf-8") as f:
            rows = list(csv.DictReader(f))
    return render_template_string(
        DASHBOARD_HTML, rows=rows, total=len(rows), plant=PLANT_SPECIES
    )


@app.route("/images/<path:filename>")
def serve_image(filename):
    return send_from_directory(IMAGES_FOLDER, filename)


@app.route("/download-csv")
def download_csv():
    return send_file(
        CSV_FILE, as_attachment=True,
        download_name=f"{PLANT_SPECIES.lower().replace(' ','_')}_growth_log.csv"
    )


@app.route("/api/latest")
def api_latest():
    rows = []
    if os.path.exists(CSV_FILE):
        with open(CSV_FILE, "r", encoding="utf-8") as f:
            rows = list(csv.DictReader(f))
    return jsonify(rows[-1] if rows else {})


@app.route("/api/all")
def api_all():
    rows = []
    if os.path.exists(CSV_FILE):
        with open(CSV_FILE, "r", encoding="utf-8") as f:
            rows = list(csv.DictReader(f))
    return jsonify(rows)


# ============================================================
# Dashboard HTML Template
# ============================================================
DASHBOARD_HTML = """
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>{{ plant }} Growth Monitor</title>
  <style>
    :root {
      --green:  #1B5E20; --green2: #2E7D32; --green3: #4CAF50; --green4: #A5D6A7;
      --bg:     #F1F8F2; --card:   #FFFFFF; --border: #C8E6C9;
      --text:   #1B2E1C; --muted:  #5A7A5B;
    }
    * { margin:0; padding:0; box-sizing:border-box; }
    body { font-family:'Segoe UI',Arial,sans-serif; background:var(--bg); color:var(--text); }

    header { background:linear-gradient(135deg,#1B5E20,#2E7D32,#388E3C);
             color:#fff; padding:20px 32px; display:flex; justify-content:space-between;
             align-items:center; box-shadow:0 3px 14px rgba(0,0,0,.2); }
    .hdr-title { font-size:22px; font-weight:700; }
    .hdr-sub   { font-size:13px; opacity:.75; margin-top:3px; }
    .hdr-right { display:flex; align-items:center; gap:8px; }
    .hdr-badge { background:rgba(255,255,255,.15); border:1px solid rgba(255,255,255,.3);
                 padding:5px 13px; border-radius:99px; font-size:13px; }
    .btn { background:rgba(255,255,255,.2); color:#fff; border:1px solid rgba(255,255,255,.35);
           padding:8px 17px; border-radius:8px; font-size:13px; text-decoration:none;
           cursor:pointer; transition:background .2s; }
    .btn:hover { background:rgba(255,255,255,.35); }

    main { padding:24px 32px; max-width:1300px; margin:0 auto; }

    .alert-banner { border-radius:12px; padding:14px 20px; margin-bottom:18px;
                    display:flex; align-items:center; gap:14px; }
    .a-harvest { background:#E8F5E9; border:2px solid #66BB6A; }
    .a-warn    { background:#FFF8E1; border:2px solid #FFB300; }
    .a-stress  { background:#FFEBEE; border:2px solid #EF9A9A; }
    .a-icon { font-size:28px; }
    .a-title { font-size:14px; font-weight:700; }
    .a-sub   { font-size:12px; color:var(--muted); margin-top:2px; }

    .summary-grid { display:grid; grid-template-columns:repeat(auto-fit,minmax(185px,1fr));
                    gap:14px; margin-bottom:22px; }
    .sc { background:var(--card); border-radius:14px; padding:18px 20px;
          border-left:4px solid var(--green3); box-shadow:0 2px 8px rgba(0,0,0,.06); }
    .sc .lbl { font-size:11px; color:var(--muted); text-transform:uppercase; letter-spacing:.5px; }
    .sc .val { font-size:26px; font-weight:800; color:var(--green2); margin-top:4px; }
    .sc .sub { font-size:12px; color:var(--muted); margin-top:2px; }

    .progress-card { background:var(--card); border-radius:14px; padding:22px;
                     box-shadow:0 2px 8px rgba(0,0,0,.06); margin-bottom:18px; }
    .progress-card h3 { font-size:14px; font-weight:600; color:var(--green2);
                        border-bottom:2px solid var(--border); padding-bottom:10px; margin-bottom:16px; }
    .stages { display:flex; }
    .stg { flex:1; text-align:center; padding:11px 4px; font-size:12px; font-weight:500;
           background:var(--border); color:var(--muted); border-right:2px solid #fff; cursor:default; }
    .stg:first-child { border-radius:8px 0 0 8px; }
    .stg:last-child  { border-radius:0 8px 8px 0; border-right:none; }
    .stg.active { background:var(--green2); color:#fff; font-weight:700; }
    .stg .sd { font-size:10px; margin-top:2px; opacity:.8; }

    .two-col { display:grid; grid-template-columns:1fr 1fr; gap:18px; margin-bottom:18px; }
    @media(max-width:820px){.two-col{grid-template-columns:1fr;}}
    .card { background:var(--card); border-radius:14px; padding:22px;
            box-shadow:0 2px 8px rgba(0,0,0,.06); }
    .card h3 { font-size:14px; font-weight:600; color:var(--green2);
               border-bottom:2px solid var(--border); padding-bottom:10px; margin-bottom:16px; }
    .latest-img { width:100%; border-radius:10px; border:2px solid var(--border);
                  object-fit:cover; max-height:290px; }
    .no-img { width:100%; height:210px; border-radius:10px; border:2px dashed var(--border);
              display:flex; align-items:center; justify-content:center;
              color:var(--muted); font-size:14px; }
    .dr { display:flex; justify-content:space-between; align-items:center;
          padding:9px 0; border-bottom:1px solid var(--border); font-size:14px; }
    .dr:last-child { border-bottom:none; }
    .dl { color:var(--muted); font-weight:500; font-size:13px; }

    .badge { padding:3px 11px; border-radius:99px; font-size:12px; font-weight:600; display:inline-block; }
    .bg { background:#E8F5E9; color:#1B5E20; }
    .by { background:#FFF8E1; color:#E65100; }
    .br { background:#FFEBEE; color:#B71C1C; }
    .bb { background:#E3F2FD; color:#0D47A1; }
    .bo { background:#FBE9E7; color:#BF360C; }
    .bgr{ background:#F5F5F5; color:#555; }

    .conf-wrap { display:flex; align-items:center; gap:8px; }
    .conf-track { flex:1; max-width:80px; height:8px; background:var(--border); border-radius:99px; }
    .conf-fill  { height:8px; border-radius:99px; background:var(--green3); }

    table { width:100%; border-collapse:collapse; font-size:13px; }
    th { background:var(--green2); color:#fff; padding:11px 13px; text-align:left;
         font-size:12px; font-weight:600; white-space:nowrap; }
    td { padding:9px 13px; border-bottom:1px solid var(--border); vertical-align:middle; }
    tr:hover td { background:#F7FBF7; }
    tr:last-child td { border-bottom:none; }
    .thumb { width:48px; height:36px; object-fit:cover; border-radius:5px; border:1px solid var(--border); }
    .mini-wrap { display:inline-block; width:55px; height:6px; background:var(--border);
                 border-radius:3px; vertical-align:middle; margin-left:4px; }
    .mini-fill { height:6px; border-radius:3px; background:var(--green3); }

    .empty-state { text-align:center; padding:52px; color:var(--muted); }
    .empty-state .ei { font-size:52px; margin-bottom:14px; }
    .empty-state p { font-size:14px; line-height:1.7; }
    code { background:#F1F8F2; padding:2px 7px; border-radius:4px; font-size:12px;
           font-family:monospace; color:var(--green2); }
    .ow { overflow-x:auto; }
  </style>
</head>
<body>

<header>
  <div>
    <div class="hdr-title">🌿 {{ plant }} Growth Monitor</div>
    <div class="hdr-sub">Daily 8:00 AM photo analysis · Roboflow AI · Local network dashboard</div>
  </div>
  <div class="hdr-right">
    <span class="hdr-badge">📋 {{ total }} entries</span>
    <a class="btn" href="/download-csv">⬇ CSV</a>
    <a class="btn" href="javascript:location.reload()">↻ Refresh</a>
  </div>
</header>

<main>
  {% set latest = rows[-1] if rows else None %}

  {# Contextual alerts based on latest growth stage #}
  {% if latest %}
    {% if latest.growth_stage == 'Mature' %}
    <div class="alert-banner a-harvest">
      <div class="a-icon">🥬</div>
      <div>
        <div class="a-title">{{ plant }} is Mature — ready for harvest!</div>
        <div class="a-sub">Detected {{ latest.date }}. Harvest soon to maintain leaf quality and prevent bolting.</div>
      </div>
    </div>
    {% elif latest.growth_stage == 'Overgrown' %}
    <div class="alert-banner a-warn">
      <div class="a-icon">⚠️</div>
      <div>
        <div class="a-title">Plant is Overgrown — past optimal harvest window.</div>
        <div class="a-sub">Detected {{ latest.date }}. Bolting may reduce taste and leaf quality.</div>
      </div>
    </div>
    {% elif latest.health_status == 'Stressed' %}
    <div class="alert-banner a-stress">
      <div class="a-icon">🔴</div>
      <div>
        <div class="a-title">Plant shows stress — check nutrient solution and lighting.</div>
        <div class="a-sub">Detected {{ latest.date }}. Review pH (5.8–6.2) and TDS (900–1100 ppm) levels.</div>
      </div>
    </div>
    {% endif %}
  {% endif %}

  {# Summary cards #}
  <div class="summary-grid">
    <div class="sc">
      <div class="lbl">Photos Logged</div>
      <div class="val">{{ total }}</div>
      <div class="sub">Days monitored</div>
    </div>
    <div class="sc">
      <div class="lbl">Current Stage</div>
      <div class="val" style="font-size:17px;margin-top:6px;">{{ latest.growth_stage if latest else '—' }}</div>
      <div class="sub">{{ latest.estimated_day_range if latest else 'No data yet' }}</div>
    </div>
    <div class="sc">
      <div class="lbl">AI Confidence</div>
      <div class="val">
        {% if latest and latest.confidence %}{{ (latest.confidence|float*100)|round(1) }}%
        {% else %}—{% endif %}
      </div>
      <div class="sub">Roboflow score</div>
    </div>
    <div class="sc">
      <div class="lbl">Health Status</div>
      <div class="val" style="font-size:17px;margin-top:6px;">{{ latest.health_status if latest else '—' }}</div>
      <div class="sub">{{ latest.date if latest else 'No data' }}</div>
    </div>
    <div class="sc">
      <div class="lbl">Plant Species</div>
      <div class="val" style="font-size:17px;margin-top:6px;">{{ plant }}</div>
      <div class="sub">Hydroponics</div>
    </div>
  </div>

  {# Growth stage progress bar #}
  {% if latest %}
  <div class="progress-card">
    <h3>🌿 {{ plant }} Growth Stage Progress</h3>
    <div class="stages">
      {% for stg, days in [('Germination','Day 1–3'),('Seedling','Day 4–10'),('Vegetative','Day 11–25'),('Mature','Day 26+'),('Overgrown','Day 30+')] %}
      <div class="stg {% if latest.growth_stage == stg %}active{% endif %}">
        {{ stg }}<div class="sd">{{ days }}</div>
      </div>
      {% endfor %}
    </div>
  </div>
  {% endif %}

  {# Latest photo + analysis panel #}
  {% if latest %}
  <div class="two-col">
    <div class="card">
      <h3>📷 Latest Photo — {{ latest.date }} at {{ latest.time }}</h3>
      {% if latest.filename %}
        <img class="latest-img" src="/images/{{ latest.filename }}"
             alt="Latest plant photo"
             onerror="this.outerHTML='<div class=no-img>Image not found in images/ folder</div>'">
      {% else %}
        <div class="no-img">No image yet</div>
      {% endif %}
      <p style="font-size:12px;color:var(--muted);margin-top:10px;">
        {{ latest.image_width }} × {{ latest.image_height }} px &nbsp;·&nbsp; Device: {{ latest.device_id }}
      </p>
    </div>

    <div class="card">
      <h3>🔬 AI Analysis Result</h3>

      <div class="dr">
        <span class="dl">Growth Stage</span>
        <span class="badge bg">{{ latest.growth_stage }}</span>
      </div>
      <div class="dr">
        <span class="dl">Estimated Age</span>
        <span style="font-weight:600;">{{ latest.estimated_day_range }}</span>
      </div>
      <div class="dr">
        <span class="dl">Health Status</span>
        {% if latest.health_status == 'Healthy' %}<span class="badge bg">{{ latest.health_status }}</span>
        {% elif latest.health_status == 'Stressed' %}<span class="badge br">{{ latest.health_status }}</span>
        {% elif latest.health_status == 'Attention Needed' %}<span class="badge by">{{ latest.health_status }}</span>
        {% else %}<span class="badge bgr">{{ latest.health_status }}</span>{% endif %}
      </div>
      <div class="dr">
        <span class="dl">AI Confidence</span>
        <div class="conf-wrap">
          <div class="conf-track">
            <div class="conf-fill" style="width:{{ (latest.confidence|float*100)|int }}%"></div>
          </div>
          <strong>{{ (latest.confidence|float*100)|round(1) }}%</strong>
        </div>
      </div>
      <div class="dr">
        <span class="dl">Detected Class</span>
        <span class="badge bb">{{ latest.detected_class or '—' }}</span>
      </div>
      <div class="dr">
        <span class="dl">Roboflow Model</span>
        <span style="font-size:12px;color:var(--muted);">{{ latest.roboflow_model }}</span>
      </div>
      {% if latest.notes %}
      <div class="dr">
        <span class="dl">Notes</span>
        <span style="font-size:12px;color:var(--muted);max-width:55%;text-align:right;">{{ latest.notes }}</span>
      </div>
      {% endif %}
    </div>
  </div>
  {% endif %}

  {# Full log table #}
  <div class="card">
    <h3>📋 Full Growth Log</h3>
    {% if rows %}
    <div class="ow">
      <table>
        <thead>
          <tr>
            <th>#</th><th>Photo</th><th>Date</th><th>Time</th>
            <th>Growth Stage</th><th>Est. Age</th><th>Health</th>
            <th>Confidence</th><th>Model Class</th><th>Device</th><th>Notes</th>
          </tr>
        </thead>
        <tbody>
          {% for row in rows|reverse %}
          <tr>
            <td style="color:var(--muted);">{{ loop.revindex }}</td>
            <td>
              {% if row.filename %}
              <img class="thumb" src="/images/{{ row.filename }}" alt="plant"
                   onerror="this.style.display='none'">
              {% else %}—{% endif %}
            </td>
            <td>{{ row.date }}</td>
            <td style="color:var(--muted);">{{ row.time }}</td>
            <td>
              {% if row.growth_stage in ['Germination','Seedling','Vegetative','Mature'] %}
                <span class="badge bg">{{ row.growth_stage }}</span>
              {% elif row.growth_stage == 'Stressed' %}<span class="badge br">{{ row.growth_stage }}</span>
              {% elif row.growth_stage == 'Overgrown' %}<span class="badge bo">{{ row.growth_stage }}</span>
              {% else %}<span class="badge bgr">{{ row.growth_stage }}</span>{% endif %}
            </td>
            <td style="color:var(--muted);font-size:12px;">{{ row.estimated_day_range }}</td>
            <td>
              {% if row.health_status == 'Healthy' %}<span class="badge bg">{{ row.health_status }}</span>
              {% elif row.health_status == 'Stressed' %}<span class="badge br">{{ row.health_status }}</span>
              {% elif row.health_status == 'Attention Needed' %}<span class="badge by">{{ row.health_status }}</span>
              {% else %}<span class="badge bgr">{{ row.health_status }}</span>{% endif %}
            </td>
            <td>
              {% if row.confidence %}
                {% set pct = (row.confidence|float*100)|round(1)|int %}
                <span style="font-size:12px;font-weight:600;">{{ pct }}%</span>
                <span class="mini-wrap"><span class="mini-fill" style="width:{{ pct }}%"></span></span>
              {% else %}—{% endif %}
            </td>
            <td><span class="badge bb" style="font-size:11px;">{{ row.detected_class or '—' }}</span></td>
            <td style="color:var(--muted);">{{ row.device_id }}</td>
            <td style="font-size:11px;color:var(--muted);max-width:160px;">{{ row.notes }}</td>
          </tr>
          {% endfor %}
        </tbody>
      </table>
    </div>
    {% else %}
    <div class="empty-state">
      <div class="ei">🌱</div>
      <p>No photos logged yet.<br>
      The ESP32-CAM will send its first photo at 8:00 AM.<br><br>
      To test the server now, run in a terminal:<br>
      <code>curl -F "file=@your_plant_photo.jpg" http://localhost:5000/upload</code>
      </p>
    </div>
    {% endif %}
  </div>

</main>
</body>
</html>
"""

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=SERVER_PORT, debug=DEBUG_MODE)
