#!/bin/bash
echo "============================================"
echo " Plant Growth Monitor - Starting Server"
echo "============================================"
echo ""

# Go to script directory
cd "$(dirname "$0")"

# Install dependencies
echo "Installing dependencies..."
pip3 install -r requirements.txt --quiet

echo ""
echo "Starting server..."
echo "Dashboard: http://localhost:5000"
echo "Press Ctrl+C to stop."
echo ""

python3 server.py
